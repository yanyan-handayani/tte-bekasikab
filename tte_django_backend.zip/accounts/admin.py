from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.utils.translation import gettext_lazy as _
from .models import User

@admin.register(User)
class CustomUserAdmin(UserAdmin):
    """
    Admin untuk custom User:
    - tetap pakai username/password Django
    - tambah relasi ke Pegawai
    - simpan legacy SHA1 PIN (read-only)
    """

    model = User

    # ===== List View =====
    list_display = (
        "username",
        "full_name",
        "pegawai",
        "is_staff",
        "is_active",
        "last_login",
    )
    list_filter = ("is_staff", "is_superuser", "is_active")
    search_fields = ("username", "full_name")
    ordering = ("username",)

    # ===== Detail Form =====
    fieldsets = (
        (_("Account"), {
            "fields": (
                "username",
                "password",
            )
        }),
        (_("Profil"), {
            "fields": (
                "full_name",
                "pegawai",
            )
        }),
        (_("Permissions"), {
            "fields": (
                "is_active",
                "is_staff",
                "is_superuser",
                "groups",
                "user_permissions",
            )
        }),
        (_("Important dates"), {
            "fields": (
                "last_login",
                "date_joined",
            )
        }),
    )

    # ===== Add User Form =====
    add_fieldsets = (
        (None, {
            "classes": ("wide",),
            "fields": (
                "username",
                "full_name",
                "pegawai",
                "password1",
                "password2",
                "is_staff",
                "is_active",
            ),
        }),
    )

    readonly_fields = ("legacy_pin_hash", "last_login", "date_joined")

    filter_horizontal = ("groups", "user_permissions")
    
