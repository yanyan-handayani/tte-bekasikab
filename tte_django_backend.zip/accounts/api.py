from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated


def as_primitive_fk(val):
    """
    Ubah FK object -> pk, kalau sudah primitive biarkan.
    """
    if val is None:
        return None
    # jika ini instance model Django (punya pk)
    if hasattr(val, "pk"):
        return val.pk
    return val

def mask_middle(s: str, left=3, right=3):
    if not s or len(s) <= left + right:
        return s
    return f"{s[:left]}***{s[-right:]}"


class MeView(APIView):
    permission_classes = [IsAuthenticated]


    def get(self, request):
        u = request.user
        peg = getattr(u, "pegawai", None)

        data_pegawai = None
        if peg:
            instansi_val = getattr(peg, "id_instansi", None)

            data_pegawai = {
                "nip": mask_middle(getattr(peg, "nip", None), 3, 3),
                "nama": mask_middle(getattr(peg, "nama_lengkap", None), 2, 2),
                "id_jabatan": as_primitive_fk(getattr(peg, "id_jabatan", None)),
                "id_instansi": as_primitive_fk(instansi_val),
                "instansi": (
                    {
                        "id": getattr(instansi_val, "pk", None),
                        "nama": getattr(instansi_val, "nama", None),
                    }
                    if hasattr(instansi_val, "pk") else None
                ),
            }

        return Response({
            "id": u.id,
            "username": u.username,
            "full_name": u.full_name,
            "pegawai": data_pegawai,
            "is_staff": u.is_staff,
            "is_superuser": u.is_superuser,
        })
