import pyotp
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework import status


class TwoFASetupView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        user = request.user

        if user.twofa_enabled:
            return Response({"detail": "2FA sudah aktif. Nonaktifkan dulu untuk setup ulang."}, status=400)

        # generate new secret every setup (kalau mau: hanya jika belum enabled)
        secret = pyotp.random_base32()
        user.twofa_secret = secret
        user.twofa_enabled = False
        user.save(update_fields=["twofa_secret", "twofa_enabled"])

        issuer = "TTE"
        label = user.username
        uri = pyotp.TOTP(secret).provisioning_uri(name=label, issuer_name=issuer)

        return Response(
            {
                # "secret": secret,     # boleh kamu sembunyikan kalau hanya mau QR
                "otpauth_uri": uri,   # ini yang biasa dipakai untuk QR
            },
            status=status.HTTP_200_OK,
        )


class TwoFAEnableView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        user = request.user
        otp = str(request.data.get("otp", "")).strip()

        if not user.twofa_secret:
            return Response({"detail": "2FA secret belum ada. Jalankan setup dulu."}, status=400)
        if not otp:
            return Response({"detail": "OTP wajib."}, status=400)

        totp = pyotp.TOTP(user.twofa_secret)
        if not totp.verify(otp, valid_window=1):
            return Response({"detail": "OTP salah."}, status=400)

        user.twofa_enabled = True
        user.save(update_fields=["twofa_enabled"])
        return Response({"detail": "2FA aktif."}, status=200)


class TwoFADisableView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        user = request.user
        otp = str(request.data.get("otp", "")).strip()

        if user.twofa_enabled:
            if not otp:
                return Response({"detail": "OTP wajib untuk menonaktifkan 2FA."}, status=400)
            totp = pyotp.TOTP(user.twofa_secret or "")
            if not totp.verify(otp, valid_window=1):
                return Response({"detail": "OTP salah."}, status=400)

        user.twofa_enabled = False
        user.twofa_secret = None
        user.twofa_backup_codes = None
        user.save(update_fields=["twofa_enabled", "twofa_secret", "twofa_backup_codes"])
        return Response({"detail": "2FA nonaktif."}, status=200)
