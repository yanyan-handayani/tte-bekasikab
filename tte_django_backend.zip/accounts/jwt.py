# accounts/jwt.py
import pyotp
from django.contrib.auth import authenticate, get_user_model
from django.utils import timezone
from rest_framework import serializers
from rest_framework_simplejwt.views import TokenObtainPairView
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer


class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
    def validate(self, attrs):
        request = self.context.get("request")

        # SimpleJWT username_field biasanya "username"
        username = attrs.get(self.username_field)
        if isinstance(username, str):
            username = username.strip()
            attrs[self.username_field] = username
        password = attrs.get("password")

        UserModel = get_user_model()

        # cari user dengan field yang benar (username_field)
        lookup = {self.username_field: username}
        user = UserModel.objects.filter(**lookup).only(
            "id", "lockout_until", "failed_login_count", "twofa_enabled", "twofa_secret"
        ).first()

        # lockout check (harusnya mulai request ke-4)
        if user and user.lockout_until and user.lockout_until > timezone.now():
            raise serializers.ValidationError(
                {"detail": "Akun terkunci sementara karena terlalu banyak percobaan login."}
            )

        if user and user.lockout_until and user.lockout_until <= timezone.now() and user.failed_login_count:
            user.failed_login_count = 0
            user.lockout_until = None
            user.save(update_fields=["failed_login_count", "lockout_until"])

        auth_user = authenticate(request=request, username=username, password=password)

        if auth_user is None:
            # password salah → hitung gagal login
            if user:
                user.register_failed_login(max_attempts=3, lock_minutes=15)

                # kalau setelah increment sudah terkunci, langsung balas lockout
                user.refresh_from_db(fields=["failed_login_count", "lockout_until"])
                if user.lockout_until and user.lockout_until > timezone.now():
                    raise serializers.ValidationError(
                        {"detail": "Akun terkunci sementara karena terlalu banyak percobaan login."}
                    )

            raise serializers.ValidationError({"detail": "Username/password salah."})

        # 2FA check
        if getattr(auth_user, "twofa_enabled", False):
            otp = (request.data.get("otp") if request else None) or attrs.get("otp")
            otp = (str(otp).strip() if otp is not None else "")

            if not otp:
                raise serializers.ValidationError({"detail": "OTP wajib untuk akun ini.", "code": "2fa_required"})

            secret = getattr(auth_user, "twofa_secret", None)
            if not secret:
                raise serializers.ValidationError({"detail": "2FA secret belum ada. Setup ulang 2FA."})

            totp = pyotp.TOTP(secret)
            if not totp.verify(otp, valid_window=1):
                auth_user.register_failed_login(max_attempts=3, lock_minutes=15)
                raise serializers.ValidationError({"detail": "OTP salah."})

        # sukses → reset
        auth_user.register_success_login()
        return super().validate(attrs)


class CustomTokenObtainPairView(TokenObtainPairView):
    serializer_class = CustomTokenObtainPairSerializer
