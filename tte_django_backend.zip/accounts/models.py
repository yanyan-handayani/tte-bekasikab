from django.contrib.auth.models import AbstractUser
from django.db import models
from core.fields import EncryptedTextField
from django.utils import timezone

class User(AbstractUser):
    pegawai = models.ForeignKey(
        "core.MstDataPegawai",
        db_column="pegawai_ref_id",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="users",
    )

    full_name = models.CharField(max_length=255, null=True, blank=True)

    # legacy SHA1 pin (40 hex)
    legacy_pin_hash = models.CharField(max_length=40, null=True, blank=True)

    failed_login_count = models.PositiveSmallIntegerField(default=0)
    lockout_until = models.DateTimeField(null=True, blank=True)

    # === 2FA ===
    twofa_enabled = models.BooleanField(default=False)
    twofa_secret = EncryptedTextField(null=True, blank=True)        # secret TOTP (encrypted)
    twofa_backup_codes = EncryptedTextField(null=True, blank=True)  # opsional
    username_hash = models.CharField(max_length=64, null=True, blank=True, unique=True, db_index=True)


    def is_locked_out(self) -> bool:
        return bool(self.lockout_until and self.lockout_until > timezone.now())

    def register_failed_login(self, max_attempts=3, lock_minutes=15):
        now = timezone.now()
        self.failed_login_count = (self.failed_login_count or 0) + 1
        if self.failed_login_count >= max_attempts:
            self.lockout_until = now + timezone.timedelta(minutes=lock_minutes)
        self.save(update_fields=["failed_login_count", "lockout_until"])

    def register_success_login(self):
        self.failed_login_count = 0
        self.lockout_until = None
        self.save(update_fields=["failed_login_count", "lockout_until"])

    def __str__(self):
        return self.username
