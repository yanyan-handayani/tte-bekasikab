from django.contrib import admin
from . import models
from core.crypto import hash_lookup
from .forms import MstDataPegawaiAdminForm
from .admin_utils import mask_mid

from django.db import connection
from django.conf import settings

def reg(model, list_display=None, search_fields=None, list_filter=None):
    class M(admin.ModelAdmin):
        pass
    if list_display:
        M.list_display = list_display
    if search_fields:
        M.search_fields = search_fields
    if list_filter:
        M.list_filter = list_filter
    admin.site.register(model, M)



# ====== JABATAN (MASTER) ======

@admin.register(models.MstJabatan)
class MstJabatanAdmin(admin.ModelAdmin):
    list_display = (
        "id_jabatan",
        "nama_jabatan",
        "instansi",
        "parent",
        "level_jabatan",
        "jenis_jabatan",
        "no_urut",
    )
    search_fields = ("nama_jabatan",)
    list_filter = ("level_jabatan", "jenis_jabatan", "instansi")
    list_select_related = ("instansi", "parent")

    # Enable Select2 autocomplete for large tables.
    autocomplete_fields = ("parent", "instansi")


# ====== SURAT + INLINE TAHAPAN ======

class SuratTahapanInline(admin.TabularInline):
    model = models.SuratTahapan
    extra = 0
    ordering = ("seq_tahapan",)
    show_change_link = True

    # Pakai FK (tanpa instansi_ref dulu).
    fields = (
        "seq_tahapan",
        "pejabat",
        "sign_type_ref",
        "sign_status_ref",
        "sign_date",
    )
    readonly_fields = ("sign_date",)

    autocomplete_fields = ("pejabat", "sign_type_ref", "sign_status_ref")


@admin.register(models.Surat)
class SuratAdmin(admin.ModelAdmin):
    list_display = ("id_surat","nomor_surat","judul_surat","instansi_ref","is_finish","create_date")
    list_filter = ("is_finish","instansi_ref")
    inlines = [SuratTahapanInline]
    autocomplete_fields = ("created_by",)
    search_fields = ("nomor_surat","judul_surat","instansi_ref","created_by__nip","created_by__nama_lengkap")



# Optional: list view terpisah SuratTahapan (kalau mau tetap ada).
@admin.register(models.SuratTahapan)
class SuratTahapanAdmin(admin.ModelAdmin):
    list_display = ("id_tahapan","surat","seq_tahapan","pejabat","sign_type_ref","sign_status_ref","sign_date")

    # Sesuaikan dengan field MstDataPegawai yang kamu punya.
    search_fields = (
        "pejabat__nip",
        "pejabat__nama_lengkap",
        "pejabat__id_jabatan__nama_jabatan",
        "instansi",
        "instansi_kode",
    )

    # instansi_ref dihapus karena fieldnya belum ada (kita tunda).
    list_filter = ("sign_type_ref","sign_status_ref")

    autocomplete_fields = ("surat","pejabat","sign_type_ref","sign_status_ref")


reg(models.RefInstansi, list_display=("id","nama","aktif","hari_kerja","login_terakhir"), search_fields=("nama","username","nip_pj","email_pj"))

@admin.register(models.MstDataPegawai)
class MstDataPegawaiAdmin(admin.ModelAdmin):
    form = MstDataPegawaiAdminForm

    list_display = (
        "nip_masked",
        "nik_masked",
        "nama_masked",
        "id_instansi",
        "id_jabatan",
        "is_active",
    )
    ordering = ("id",)
    list_filter = ("is_active", "id_instansi", "id_jabatan")
    list_select_related = ("id_instansi", "id_jabatan")

    # WAJIB untuk autocomplete_fields yang mengarah ke MstDataPegawai
    # (SuratAdmin / SuratTahapanAdmin / Inline)
    search_fields = ("nip_hash", "nik_hash", "nama_lengkap_hash")

    readonly_fields = ("nip_hash", "nik_hash", "nama_lengkap_hash")

    # Biar FK instansi/jabatan nyaman kalau tabel besar
    autocomplete_fields = ("id_instansi", "id_jabatan")

    fieldsets = (
        (None, {"fields": ("nip", "nik", "nama_lengkap", "id_instansi", "id_jabatan", "is_active")}),
        ("Profil", {"classes": ("collapse",), "fields": ("tempat_lahir", "tgl_lahir", "golongan", "eselon", "pendidikan", "keterangan")}),
        ("Index (readonly)", {"classes": ("collapse",), "fields": ("nip_hash", "nik_hash", "nama_lengkap_hash")}),
    )

    @admin.display(description="NIP")
    def nip_masked(self, obj):
        return mask_mid(obj.nip, 3, 3)

    @admin.display(description="NIK")
    def nik_masked(self, obj):
        return mask_mid(obj.nik, 3, 3)

    @admin.display(description="Nama")
    def nama_masked(self, obj):
        n = (obj.nama_lengkap or "").strip()
        if not n:
            return "-"
        # contoh masking nama: 2 huruf awal
        return (n[:2] + "***") if len(n) > 2 else (n[0] + "***")

    def get_search_results(self, request, queryset, search_term):
        """
        Search/autocomplete:
        - user ketik NIP/NIK/Nama plaintext
        - kita ubah ke hash -> exact match
        """
        qs, use_distinct = super().get_search_results(request, queryset, search_term)

        term = (search_term or "").strip()
        if not term:
            return qs, use_distinct

        h = hash_lookup(term)
        q2 = queryset.filter(nip_hash=h) | queryset.filter(nik_hash=h) | queryset.filter(nama_lengkap_hash=h)

        try:
            qs = qs.union(q2)
        except Exception:
            qs = (qs | q2)

        return qs, use_distinct


reg(models.TteInstansi, list_display=("id","tins_nama","create_date"), search_fields=("tins_nama",))
reg(models.TteJabatan, list_display=("id","tjab_nama","tjab_instansi","tjab_parent_jabatan"), search_fields=("tjab_nama",), list_filter=("tjab_instansi",))
reg(models.TteUser, list_display=("id_usr","nama_usr","full_usr","email_usr","is_active","instansi_fk","jabatan_loc"), search_fields=("nama_usr","full_usr","email_usr","tlp_usr"), list_filter=("is_active","instansi_fk"))


@admin.register(models.Asda)
class AsdaAdmin(admin.ModelAdmin):
    list_display = ("id_loc_asda", "nama_jabatan", "pegawai", "jenis_jabatan", "id_instansi")
    search_fields = ("id_loc_asda", "nama_jabatan", "pegawai__nip", "pegawai__nama", "pegawai__nama_lengkap")
    list_filter = ("jenis_jabatan", "id_instansi")
    autocomplete_fields = ("pegawai",)   # ✅ ini yang bikin field pegawai jadi autocomplete

    def get_queryset(self, request):
        return super().get_queryset(request).select_related("pegawai")

@admin.register(models.AsdaSkpd)
class AsdaSkpdAdmin(admin.ModelAdmin):
    list_display = ("id_asda_skpd", "asda", "skpd", "kepala_pegawai")
    search_fields = (
        "asda__id_loc_asda",
        "asda__nama_jabatan",
        "skpd__id",        # sesuaikan
        "skpd__nama",      # sesuaikan
        "kepala_pegawai__nip",
        "kepala_pegawai__nama",
        "kepala_pegawai__nama_lengkap",
    )
    list_filter = ("asda", "skpd")
    autocomplete_fields = ("asda", "skpd", "kepala_pegawai")  # ✅ ini yang kamu mau

    def get_queryset(self, request):
        return super().get_queryset(request).select_related("asda", "skpd", "kepala_pegawai")


reg(models.RoleUsr, list_display=("id_role","role_name","id_group"), search_fields=("role_name",), list_filter=("id_group",))
reg(models.Menu, list_display=("id_menu","nama_menu","url_menu","parent_menu","active_menu","seq_menu"), search_fields=("nama_menu","url_menu"), list_filter=("active_menu","parent_menu"))
reg(models.MenuFeature, list_display=("id_feture","id_role","id_menu","feature"), list_filter=("id_role","id_menu","feature"))

reg(models.Preferences, list_display=("preference_id","preference_name","preference_created"), search_fields=("preference_name",))
reg(models.PreferencesDetail, list_display=("preference_id","preference_name","preference_parent","preference_created"), search_fields=("preference_name",), list_filter=("preference_parent",))
reg(models.RefTemplate, list_display=("id_tmp","nama_template","file_template"), search_fields=("nama_template","file_template"))


@admin.register(models.Notifikasi)
class NotifikasiAdmin(admin.ModelAdmin):
    list_display = ("id", "display_pegawai", "type", "no_surat", "created")
    search_fields = (
        "pegawai__nip",
        "pegawai__nama",
        "pegawai__nama_lengkap",
        "no_surat",
        "perihal",
        "message",
    )
    list_filter = ("type", "created")
    date_hierarchy = "created"
    ordering = ("-created", "-id")

    autocomplete_fields = ("pegawai",)

    @admin.display(description="Pegawai", ordering="pegawai__nip")
    def display_pegawai(self, obj):
        if not obj.pegawai_id or not obj.pegawai:
            return "-"
        nip = getattr(obj.pegawai, "nip", "")
        nama = getattr(obj.pegawai, "nama_lengkap", None) or getattr(obj.pegawai, "nama", "")
        return f"{nip} - {nama}" if (nip or nama) else str(obj.pegawai)

    def get_queryset(self, request):
        return super().get_queryset(request).select_related("pegawai")



@admin.register(models.TelegramNotif)
class TelegramNotifAdmin(admin.ModelAdmin):
    list_display = ("tn_id", "display_pegawai", "tn_chat_id", "tn_status")
    search_fields = (
        "pegawai__nip",
        "pegawai__nama",
        "tn_chat_id",
    )
    list_filter = ("tn_status",)
    autocomplete_fields = ("pegawai",)

    @admin.display(description="Pegawai", ordering="pegawai__nip")
    def display_pegawai(self, obj):
        if not obj.pegawai:
            return "-"
        return f"{obj.pegawai.nip} - {obj.pegawai.nama_lengkap}"


@admin.register(models.LogApp)
class LogAppAdmin(admin.ModelAdmin):
    list_display = ("la_id", "la_type", "display_user", "display_pegawai", "la_time")
    list_filter = ("la_type", "la_time", "user", "pegawai")
    date_hierarchy = "la_time"
    ordering = ("-la_time", "-la_id")

    # INI KUNCI: bikin FK jadi select2 + ajax
    autocomplete_fields = ("user", "pegawai")

    search_fields = (
        "la_type",
        "la_desc",
        "user__username",
        "user__full_name",
        "pegawai__nip",
        "pegawai__nama",
        "pegawai__nama_lengkap",
    )

    @admin.display(description="User", ordering="user__username")
    def display_user(self, obj):
        return getattr(obj.user, "username", None) or getattr(obj.user, "full_name", None) or "-"

    @admin.display(description="Pegawai", ordering="pegawai__nip")
    def display_pegawai(self, obj):
        if not obj.pegawai_id:
            return "-"
        nip = getattr(obj.pegawai, "nip", None)
        nama = getattr(obj.pegawai, "nama", None) or getattr(obj.pegawai, "nama_lengkap", None)
        return f"{nip} - {nama}" if nip and nama else (nip or nama or "-")

    def get_queryset(self, request):
        # optional: kecilkan beban list view
        qs = super().get_queryset(request)
        return qs.select_related("user", "pegawai")


@admin.register(models.LogUsr)
class LogUsrAdmin(admin.ModelAdmin):
    list_display = ("id_log", "display_user", "display_pegawai", "waktu", "kategori", "display_ipaddr")
    list_filter = ("kategori", "waktu", "user", "pegawai")
    date_hierarchy = "waktu"
    ordering = ("-waktu", "-id_log")

    autocomplete_fields = ("user", "pegawai")

    search_fields = (
        "user__username",
        "user__full_name",
        "pegawai__nip",
        "pegawai__nama",
        "pegawai__nama_lengkap",
        "ipaddr",
    )

    @admin.display(description="User", ordering="user__username")
    def display_user(self, obj):
        return getattr(obj.user, "username", None) or getattr(obj.user, "full_name", None) or "-"

    @admin.display(description="Pegawai", ordering="pegawai__nip")
    def display_pegawai(self, obj):
        if not obj.pegawai_id:
            return "-"
        nip = getattr(obj.pegawai, "nip", None)
        nama = getattr(obj.pegawai, "nama", None) or getattr(obj.pegawai, "nama_lengkap", None)
        return f"{nip} - {nama}" if nip and nama else (nip or nama or "-")

    @admin.display(description="IP Address")
    def display_ipaddr(self, obj):
        try:
            return obj.ipaddr or "-"
        except Exception:
            return "-"

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs.select_related("user", "pegawai")


@admin.register(models.LogBsre)
class LogBsreAdmin(admin.ModelAdmin):
    list_display = ("id_log", "display_pegawai", "display_surat", "waktu", "kategori", "ipaddr", "file")
    list_filter = ("kategori", "waktu", "pegawai")
    date_hierarchy = "waktu"
    ordering = ("-waktu", "-id_log")

    # INI JUGA KUNCI
    autocomplete_fields = ("pegawai", "surat")

    search_fields = (
        "pegawai__nip",
        "pegawai__nama",
        "pegawai__nama_lengkap",
        "file",
        "msg_log",
        "surat__nomor",
        "surat__perihal",
        "ipaddr",
    )

    @admin.display(description="Pegawai", ordering="pegawai__nip")
    def display_pegawai(self, obj):
        if not obj.pegawai_id:
            return "-"
        nip = getattr(obj.pegawai, "nip", None)
        nama = getattr(obj.pegawai, "nama", None) or getattr(obj.pegawai, "nama_lengkap", None)
        return f"{nip} - {nama}" if nip and nama else (nip or nama or "-")

    @admin.display(description="Surat")
    def display_surat(self, obj):
        if not obj.surat_id or not obj.surat:
            return "-"
        nomor = getattr(obj.surat, "nomor", None)
        perihal = getattr(obj.surat, "perihal", None)
        return f"{nomor} - {perihal}" if nomor and perihal else (nomor or perihal or f"Surat #{obj.surat_id}")

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs.select_related("pegawai", "surat")


reg(models.Setting, list_display=("id_set","nama_web","telepon_web","email_web","is_maintenance"), search_fields=("nama_web","email_web"), list_filter=("is_maintenance",))
reg(models.SuratFinish, list_display=("id","finish"), search_fields=("finish",))
reg(models.SuratMsg, list_display=("id_msg","id_surat","msg_create","msg_date"), search_fields=("id_surat","msg_create"))
reg(models.SuratSignStatus, list_display=("id_status","nama_status"), search_fields=("nama_status",))
reg(models.SuratSignType, list_display=("id_sign","nama_sign"), search_fields=("nama_sign",))
reg(models.TmpSrtDet, list_display=("id_tmp","id_req","id_ref_template","id_tr","row_seq"), search_fields=("id_req",), list_filter=("id_ref_template",))
reg(models.TmpSrtFile, list_display=("id_srt_file","id_tr","file_name"), search_fields=("file_name",))
reg(models.TaJabatan, list_display=("id","nip","id_jabatan","status","jabatan_awal","jabatan_akhir"), search_fields=("nip__nip","nip__nama_lengkap"), list_filter=("status",))
