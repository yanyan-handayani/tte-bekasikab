from django.utils import timezone
from rest_framework import serializers
from core.models import Surat, SuratTahapan


class SuratTahapanSerializer(serializers.ModelSerializer):
    pejabat_display = serializers.SerializerMethodField()
    instansi_display = serializers.SerializerMethodField()
    sign_type_display = serializers.SerializerMethodField()
    sign_status_display = serializers.SerializerMethodField()

    class Meta:
        model = SuratTahapan
        fields = [
            "id_tahapan",
            "surat",
            "seq_tahapan",
            "pejabat",              # berisi nip (to_field)
            "pejabat_display",
            "sign_type_ref",
            "sign_type_display",
            "sign_status_ref",
            "sign_status_display",
            "instansi_ref",
            "instansi_display",
            "pejabat_nama",
            "pejabat_jabatan",
            "instansi",
            "sign_date",
        ]
        read_only_fields = ["id_tahapan", "surat", "sign_date"]

    def get_pejabat_display(self, obj):
        p = obj.pejabat
        if not p:
            return None
        return {
            "nip": getattr(p, "nip", None),
            "nama": getattr(p, "nama", None),
            "jabatan": getattr(p, "jabatan", None) or getattr(obj, "pejabat_jabatan", None),
        }

    def get_instansi_display(self, obj):
        i = obj.instansi_ref
        if not i:
            return None
        return {"id": getattr(i, "id", None), "nama": getattr(i, "nama", None)}

    def get_sign_type_display(self, obj):
        t = obj.sign_type_ref
        if not t:
            return None
        return {"id_sign": getattr(t, "id_sign", None), "nama": getattr(t, "nama", None)}

    def get_sign_status_display(self, obj):
        s = obj.sign_status_ref
        if not s:
            return None
        return {"id_status": getattr(s, "id_status", None), "nama": getattr(s, "nama", None)}


class SuratListSerializer(serializers.ModelSerializer):
    instansi_nama = serializers.SerializerMethodField()
    created_by_nip = serializers.SerializerMethodField()
    created_by_nama = serializers.SerializerMethodField()
    file_surat_url = serializers.SerializerMethodField()
    current_tahapan = serializers.SerializerMethodField()

    class Meta:
        model = Surat
        fields = [
            "id_surat",
            "nomor_surat",
            "judul_surat",
            "tujuan_surat",
            "instansi_ref",
            "instansi_nama",
            "create_date",
            "is_finish",
            "date_finish",
            "created_by_nip",
            "created_by_nama",
            "file_surat_url",
            "current_tahapan",
        ]

    def get_instansi_nama(self, obj):
        i = obj.instansi_ref
        return getattr(i, "nama", None) if i else None

    def get_created_by_nip(self, obj):
        cb = obj.created_by
        return getattr(cb, "nip", None) if cb else None

    def get_created_by_nama(self, obj):
        cb = obj.created_by
        return getattr(cb, "nama", None) if cb else None

    def get_file_surat_url(self, obj):
        f = obj.file_surat
        if not f:
            return None
        try:
            return f.url  # presigned (kalau media private)
        except Exception:
            return None

    def get_current_tahapan(self, obj):
        # tahapan yang paling “aktif” biasanya yang statusnya pending.
        # kalau kamu punya id_status khusus pending, set di settings / constant.
        qs = obj.tahapan_set.all().order_by("seq_tahapan", "id_tahapan")
        t = qs.first()
        if not t:
            return None
        return {
            "id_tahapan": t.id_tahapan,
            "seq_tahapan": t.seq_tahapan,
            "pejabat_nip": getattr(t.pejabat, "nip", None) if t.pejabat else None,
            "pejabat_nama": getattr(t.pejabat, "nama", None) if t.pejabat else t.pejabat_nama,
            "sign_status": getattr(t.sign_status_ref, "id_status", None) if t.sign_status_ref else None,
        }


class SuratDetailSerializer(serializers.ModelSerializer):
    instansi_nama = serializers.SerializerMethodField()
    created_by_nip = serializers.SerializerMethodField()
    created_by_nama = serializers.SerializerMethodField()
    file_surat_url = serializers.SerializerMethodField()
    tahapan = SuratTahapanSerializer(source="tahapan_set", many=True, read_only=True)

    class Meta:
        model = Surat
        fields = [
            "id_surat",
            "nomor_surat",
            "judul_surat",
            "tujuan_surat",
            "instansi_ref",
            "instansi_nama",
            "file_surat",
            "file_surat_url",
            "created_by",
            "created_by_nip",
            "created_by_nama",
            "create_date",
            "is_finish",
            "date_finish",
            "show_date",
            "id_dokumen",
            "tahapan",
        ]
        read_only_fields = ["id_surat", "created_by", "create_date", "file_surat"]

    def get_instansi_nama(self, obj):
        i = obj.instansi_ref
        return getattr(i, "nama", None) if i else None

    def get_created_by_nip(self, obj):
        cb = obj.created_by
        return getattr(cb, "nip", None) if cb else None

    def get_created_by_nama(self, obj):
        cb = obj.created_by
        return getattr(cb, "nama", None) if cb else None

    def get_file_surat_url(self, obj):
        f = obj.file_surat
        if not f:
            return None
        return f.url


class SuratCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Surat
        fields = ["nomor_surat", "judul_surat", "tujuan_surat", "instansi_ref"]

    def create(self, validated_data):
        request = self.context["request"]
        peg = getattr(request.user, "pegawai", None)
        validated_data["created_by"] = peg  # FK ke MstDataPegawai (to_field nip)
        validated_data["create_date"] = timezone.now()
        # is_finish default sudah 1 (On Process)
        return super().create(validated_data)


class SuratUploadPdfSerializer(serializers.Serializer):
    file_surat = serializers.FileField()
