from rest_framework.routers import DefaultRouter
from core.api.views import SuratViewSet, SuratTahapanViewSet

router = DefaultRouter()
router.register(r"core/surat", SuratViewSet, basename="core-surat")
router.register(r"core/tahapan", SuratTahapanViewSet, basename="core-tahapan")

urlpatterns = router.urls
