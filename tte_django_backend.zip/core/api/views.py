from django.db import transaction
from django.utils import timezone
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from core.models import Surat, SuratTahapan
from core.api.permissions import IsSuratOwnerOrStaff
from core.api.serializers import (
    SuratListSerializer, SuratDetailSerializer, SuratCreateSerializer,
    SuratUploadPdfSerializer, SuratTahapanSerializer
)

# Sesuaikan ID status ini sesuai tabel SuratSignStatus di DB kamu
SIGN_STATUS_PENDING = 1
SIGN_STATUS_SIGNED  = 2
SIGN_STATUS_REJECT  = 3


class SuratViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated, IsSuratOwnerOrStaff]
    lookup_field = "id_surat"
    queryset = Surat.objects.all().order_by("-id_surat")

    def get_queryset(self):
        qs = super().get_queryset()

        # Filter efisien untuk Vue:
        # ?q=... (nomor/judul/tujuan)
        q = self.request.query_params.get("q")
        if q:
            qs = qs.filter(
                # MySQL: icontains ok
                # sesuaikan kalau mau lebih ketat
                nomor_surat__icontains=q
            ) | qs.filter(judul_surat__icontains=q) | qs.filter(tujuan_surat__icontains=q)

        # ?instansi=<id>
        instansi = self.request.query_params.get("instansi")
        if instansi:
            qs = qs.filter(instansi_ref_id=instansi)

        # default: non-staff hanya lihat surat miliknya
        if not (self.request.user.is_staff or self.request.user.is_superuser):
            peg = getattr(self.request.user, "pegawai", None)
            if peg:
                qs = qs.filter(created_by_id=getattr(peg, "nip", None))
            else:
                qs = qs.none()

        return qs

    def get_serializer_class(self):
        if self.action == "list":
            return SuratListSerializer
        if self.action == "create":
            return SuratCreateSerializer
        if self.action == "upload_pdf":
            return SuratUploadPdfSerializer
        return SuratDetailSerializer

    def perform_create(self, serializer):
        serializer.save()  # create() di serializer sudah set created_by & create_date

    @action(detail=True, methods=["post"], url_path="upload-pdf")
    def upload_pdf(self, request, id_surat=None):
        surat = self.get_object()
        ser = self.get_serializer(data=request.data)
        ser.is_valid(raise_exception=True)

        surat.file_surat = ser.validated_data["file_surat"]
        surat.save(update_fields=["file_surat"])
        return Response({
            "id_surat": surat.id_surat,
            "file_surat": surat.file_surat.name,
            "file_surat_url": surat.file_surat.url,
        }, status=200)

    @action(detail=True, methods=["get"], url_path="file-url")
    def file_url(self, request, id_surat=None):
        surat = self.get_object()
        if not surat.file_surat:
            return Response({"detail": "Belum ada file_surat."}, status=404)
        return Response({"url": surat.file_surat.url})

    @action(detail=True, methods=["post"], url_path="submit")
    def submit(self, request, id_surat=None):
        surat = self.get_object()

        # minimal rule: harus ada file_surat untuk submit
        if not surat.file_surat:
            return Response({"detail": "Upload file PDF dulu sebelum submit."}, status=400)

        # set show_date kalau dibutuhkan untuk tampil di frontend
        if surat.show_date is None:
            surat.show_date = timezone.now()
            surat.save(update_fields=["show_date"])

        # set tahapan pertama pending kalau tahapan ada
        first = surat.tahapan_set.order_by("seq_tahapan", "id_tahapan").first()
        if first and first.sign_status_ref_id is None:
            first.sign_status_ref_id = SIGN_STATUS_PENDING
            first.save(update_fields=["sign_status_ref_id"])

        return Response({"detail": "Surat disubmit."}, status=200)

    @action(detail=True, methods=["get", "post"], url_path="tahapan")
    def tahapan(self, request, id_surat=None):
        surat = self.get_object()

        if request.method.lower() == "get":
            qs = surat.tahapan_set.all().order_by("seq_tahapan", "id_tahapan")
            return Response(SuratTahapanSerializer(qs, many=True).data)

        # tambah tahapan (owner/staff)
        ser = SuratTahapanSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        with transaction.atomic():
            obj = ser.save(surat=surat)
        return Response(SuratTahapanSerializer(obj).data, status=status.HTTP_201_CREATED)


class SuratTahapanViewSet(viewsets.GenericViewSet):
    permission_classes = [IsAuthenticated]
    lookup_field = "id_tahapan"
    queryset = SuratTahapan.objects.select_related(
        "surat", "pejabat", "sign_type_ref", "sign_status_ref", "instansi_ref"
    )

    @action(detail=True, methods=["post"], url_path="sign")
    def sign(self, request, id_tahapan=None):
        """
        Action signer: panggil BSrE untuk tanda tangan, lalu update status.
        Payload minimal:
        - pin / passphrase (opsional tergantung BSrE)
        - mode (paraf / tte) bisa baca dari sign_type_ref
        """
        t = self.get_object()

        # validasi "giliran"
        peg = getattr(request.user, "pegawai", None)
        if peg and t.pejabat_id and t.pejabat_id != peg.nip:
            return Response({"detail": "Bukan tahapan Anda."}, status=403)

        if not t.surat.file_surat:
            return Response({"detail": "Surat belum memiliki file PDF."}, status=400)

        # ======= BSrE INTEGRATION (stub) =======
        # TODO: panggil service bsrE:
        # - download PDF dari MinIO (t.surat.file_surat.open())
        # - kirim ke BSrE untuk sign sesuai sign_type_ref
        # - hasil PDF signed upload ke MinIO (mis: surat-signed/...)
        # - update t.sign_date & t.sign_status_ref
        #
        # Untuk sekarang, kita update status saja dulu:
        t.sign_status_ref_id = SIGN_STATUS_SIGNED
        t.sign_date = timezone.now()
        t.save(update_fields=["sign_status_ref_id", "sign_date"])

        return Response({"detail": "OK signed.", "tahapan": SuratTahapanSerializer(t).data}, status=200)

    @action(detail=True, methods=["post"], url_path="reject")
    def reject(self, request, id_tahapan=None):
        """
        Reject by staff/verifikator.
        """
        t = self.get_object()
        if not request.user.is_staff:
            return Response({"detail": "Hanya staff."}, status=403)

        t.sign_status_ref_id = SIGN_STATUS_REJECT
        t.save(update_fields=["sign_status_ref_id"])
        return Response({"detail": "Rejected.", "tahapan": SuratTahapanSerializer(t).data}, status=200)
